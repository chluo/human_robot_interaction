chmod u+x ./intoxicated.py
./intoxicated.py cmd_vel:=cmd_vel_mux/input/teleop

