#!/bin/bash
rostopic pub keys std_msgs/String w --once
rostopic pub keys std_msgs/String d --once
rostopic pub keys std_msgs/String s --once
