# rosbook
This repository contains example code to accompany the book [Programming Robots with ROS](http://www.amazon.com/Programming-Robots-ROS-Practical-Introduction/dp/1449323898/ref=sr_1_1?ie=UTF8&qid=1453484937&sr=8-1)

### Errata
We are grateful to the readers who have found and reported errata in the book. There is an [official Errata page](http://www.oreilly.com/catalog/errata.csp?isbn=0636920024736) on the O'Reilly website which lists the known errata in the printed book. The code available in this Github repo has the errata corrected, and therefore may be slightly different from the code listings provided in the book.
