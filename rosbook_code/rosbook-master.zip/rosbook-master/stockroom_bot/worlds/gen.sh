#!/bin/bash
set -o verbose
empy aisle.world.em > aisle.world
