#!/bin/bash
montage grasp_0.jpg grasp_1.jpg grasp_2.jpg grasp_3.jpg -geometry 640x480+2+2 grasps.jpg
