#!/bin/bash
alias r2lhome="./r2_cli.py left   0.5 -0.5 1  1.57 0 -1.57"
alias r2rhome="./r2_cli.py right -0.5 -0.5 1 -1.57 0 -1.57"
alias r2home="r2lhome;r2rhome"
